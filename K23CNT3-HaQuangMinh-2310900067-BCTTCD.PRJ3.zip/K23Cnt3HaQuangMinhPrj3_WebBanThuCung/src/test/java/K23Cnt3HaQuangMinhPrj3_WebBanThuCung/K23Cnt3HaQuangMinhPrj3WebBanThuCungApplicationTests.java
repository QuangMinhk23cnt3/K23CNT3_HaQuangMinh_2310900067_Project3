package K23Cnt3HaQuangMinhPrj3_WebBanThuCung;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K23Cnt3HaQuangMinhPrj3WebBanThuCungApplicationTests {

	@Test
	void contextLoads() {
	}

}
