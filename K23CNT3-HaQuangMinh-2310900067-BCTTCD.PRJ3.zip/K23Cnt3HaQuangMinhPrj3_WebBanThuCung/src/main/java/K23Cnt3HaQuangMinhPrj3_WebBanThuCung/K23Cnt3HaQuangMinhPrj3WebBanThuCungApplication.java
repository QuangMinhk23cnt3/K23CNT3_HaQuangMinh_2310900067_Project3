package K23Cnt3HaQuangMinhPrj3_WebBanThuCung;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K23Cnt3HaQuangMinhPrj3WebBanThuCungApplication {

	public static void main(String[] args) {
		SpringApplication.run(K23Cnt3HaQuangMinhPrj3WebBanThuCungApplication.class, args);
        System.out.println("Quang Minh");
	}

}
