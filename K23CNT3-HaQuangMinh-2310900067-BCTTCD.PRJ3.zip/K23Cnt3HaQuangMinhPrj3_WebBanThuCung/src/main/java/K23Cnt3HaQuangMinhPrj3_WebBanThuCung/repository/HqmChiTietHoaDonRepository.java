package K23Cnt3HaQuangMinhPrj3_WebBanThuCung.repository;

import K23Cnt3HaQuangMinhPrj3_WebBanThuCung.entity.HqmChiTietHoaDon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HqmChiTietHoaDonRepository extends JpaRepository<HqmChiTietHoaDon, Integer> {

}
